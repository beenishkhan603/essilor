// components/NavBar.js
'use client';
import { useState } from 'react';
import Link from 'next/link';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import MenuIcon from '@mui/icons-material/Menu';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';

const NavBar = () => {
	const [drawerOpen, setDrawerOpen] = useState(false);

	const handleDrawerOpen = () => {
		setDrawerOpen(true);
	};

	const handleDrawerClose = () => {
		setDrawerOpen(false);
	};

	return (
		<>
			<AppBar position="static">
				<Toolbar>
					<Link href="/">
						<Typography variant="h6" component="div" sx={{ flexGrow: 1 }}>
							Your Logo
						</Typography>
					</Link>
					<IconButton
						size="large"
						edge="end"
						color="inherit"
						aria-label="menu"
						onClick={handleDrawerOpen}
					>
						<MenuIcon />
					</IconButton>
				</Toolbar>
			</AppBar>

			{/* Drawer for mobile */}
			<Drawer anchor="top" open={drawerOpen} onClose={handleDrawerClose}>
				<List>
					<Link href="/">
						<ListItem button onClick={handleDrawerClose}>
							<Typography variant="h6">Home</Typography>
						</ListItem>
					</Link>
					<Link href="/about">
						<ListItem button onClick={handleDrawerClose}>
							<Typography variant="h6">About Us</Typography>
						</ListItem>
					</Link>
					<Link href="/products">
						<ListItem button onClick={handleDrawerClose}>
							<Typography variant="h6">All Products</Typography>
						</ListItem>
					</Link>
					{/* Add more links as needed */}
				</List>
			</Drawer>
		</>
	);
};

export default NavBar;
