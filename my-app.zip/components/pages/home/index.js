import { Grid, Box, Container } from '@mui/material';

import Header from '@/components/header';
import Footer from '@/components/footer';
import Lens from '@/components/lens';
import DiscoverBrand from '@/components/dicoverOurBrand';

import '../../global.css';
import NewLetter from '@/components/newsLetter';

export default function Home() {
	return (
		<>
			<Header />
			<Box className={`primaryBg`}>
				<Container maxWidth="lg">
					<Lens />
					<DiscoverBrand />
				</Container>
			</Box>
			<Box>
				<Container maxWidth="lg">
					<NewLetter />
				</Container>
			</Box>
			<Footer />
		</>
	);
}
