import { Grid } from '@mui/material';
import React from 'react';
import styles from './style.module.css';
const About = () => {
	return (
		<>
			<Grid>
				<p>Choosing Essilor is choosing a committed brand</p>
				<p>
					Making the choice to trust Essilor® solutions isn’t just choosing the
					world leader in prescription glasses – it’s choosing the lenses of a
					committed brand with a mission: see more to be more. With a long track
					record of French design and lens fabrication, dating back to 1849, our
					unique capacity for innovation allows us to continually develop the
					best vision solutions and to respond to all needs.
				</p>
			</Grid>
			<Grid container direction="row" className={styles.whyChoose}>
				<p>Why choose Essilor?</p>
				<Grid item md={6} sm={6} xs={6} lg={6}>
					<p>#1</p>
					<p>lens brand recommended by eye care professionals worldwide</p>
				</Grid>
				<Grid item md={6} sm={6} xs={6} lg={6}>
					<p>+170</p>
					<p>years of research on eye health</p>
				</Grid>
			</Grid>
			<Grid>
				<p>80% of what we learn is processed through our eyes</p>
				<p>
					This is why, at EssilorLuxottica, we believe that everyone, everywhere
					should be able to enjoy the life-changing benefits of vision
					correction and vision protection. Our mission is to help people see
					more, be more and live life to its fullest. Utilising our portfolio of
					lens technologies, we aim to enable people everywhere to learn, to
					work, to express themselves and to fulfill their potential. To meet
					this objective for all, we create and innovate continually so that we
					can propose adapted, custom lenses for all lifestyles.
				</p>
			</Grid>
			<Grid direction="row" container>
				<Grid item md={6} lg={6} sm={6} xs={6}>
					<p>About Essilor</p>
				</Grid>
				<Grid item md={6} lg={6} sm={6} xs={6}></Grid>
			</Grid>
		</>
	);
};
export default About;
