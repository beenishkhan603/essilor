'use client';
import React from 'react';
// Import Swiper React components
import { Swiper, SwiperSlide } from 'swiper/react';

// Import Swiper styles
import '../global.css';
import 'swiper/css';
import 'swiper/css/pagination';
import 'swiper/css/navigation';

// import required modules
import { Pagination, Navigation } from 'swiper/modules';

export default function App(props) {
	const { items } = props;
	const isMobile = window.innerWidth <= 768;
	return (
		<>
			<Swiper
				slidesPerView={isMobile ? 'auto' : 3}
				centeredSlides={isMobile ? true : false}
				spaceBetween={30}
				pagination={{
					clickable: true,
				}}
				navigation={!isMobile}
				modules={[Pagination, Navigation]}
				className="mySwiper"
			>
				{items.map((item, index) => (
					<SwiperSlide key={index}>{item}</SwiperSlide>
				))}
			</Swiper>
		</>
	);
}
