import { TextField, Grid } from '@mui/material';
import React from 'react';

import styles from './style.module.css';

const NewLetter = () => {
	return (
		<>
			<div className={styles.newsletterContainer}>
				<Grid direction="row" container>
					<Grid item md={5} lg={5} sm={12} xs={12}>
						<p className={styles.subHeading}>Find your nearest optician</p>
						<p className={styles.heading}>
							Get an Essilor lens solution at a partnered optician
						</p>
						<TextField type="text" fullWidth className={styles.textField} />
						<button className={styles.newsLetterBtn}>Find an optician</button>
					</Grid>
				</Grid>
			</div>
		</>
	);
};
export default NewLetter;
