import HomePage from '@/components/pages/home';

export default function Home() {
	return (
		<>
			<HomePage />
		</>
	);
}
