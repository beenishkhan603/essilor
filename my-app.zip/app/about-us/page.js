import About from '@/components/pages/about';

export default function Home() {
	return (
		<>
			<About />
		</>
	);
}
